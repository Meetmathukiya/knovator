import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class LanguageDetails {
  TextEditingController language;
  LanguageDetails({
    required this.language
  });
}
