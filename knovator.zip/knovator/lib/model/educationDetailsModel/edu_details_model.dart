import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class EducationDetails {
  TextEditingController schoolName;
  TextEditingController graduationDate;
  TextEditingController percent;
  EducationDetails({
    required this.schoolName,
    required this.graduationDate,
    required this.percent,
  });
}
