import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class SkillDetails {
  TextEditingController skillName;
  SkillDetails({
    required this.skillName
  });
}
