package com.example.knovator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
